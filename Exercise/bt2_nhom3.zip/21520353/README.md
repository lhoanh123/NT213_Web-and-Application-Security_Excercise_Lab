Mở cmd tại thư mục chứa file docker-compose sau đó chạy lần lượt các lệnh sau:
docker-compose build 
docker-compose up

form đăng kí: http://www.localhost/
database: http://www.localhost:8001/ 
tài khoản database: my (password: 31072003)
